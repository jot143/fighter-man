================================================================================
BLE SENSOR INTERFACE - SETUP INSTRUCTIONS
================================================================================

This document provides step-by-step instructions for setting up the Python
environment and installing dependencies for the BLE sensor interface library.

================================================================================
SYSTEM REQUIREMENTS
================================================================================

- Python 3.x (Python 3.7+ recommended)
- Bluetooth hardware and drivers
- Platform-specific requirements:

  Linux:
    - BlueZ Bluetooth stack
    - libbluetooth-dev

  macOS:
    - Built-in Bluetooth support
    - Xcode Command Line Tools (for some dependencies)

  Windows:
    - Not fully supported (bluepy is Linux/macOS only)

================================================================================
STEP 1: INSTALL SYSTEM DEPENDENCIES
================================================================================

Linux (Ubuntu/Debian):
----------------------
sudo apt-get update
sudo apt-get install python3-pip python3-venv
sudo apt-get install libbluetooth-dev bluez

macOS:
------
# Install Xcode Command Line Tools if not already installed
xcode-select --install

# Python 3 should already be installed, verify with:
python3 --version

================================================================================
STEP 2: CREATE VIRTUAL ENVIRONMENT
================================================================================

# Navigate to the project directory
cd /path/to/blue

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
# On Linux/macOS:
source venv/bin/activate

# On Windows (if supported):
venv\Scripts\activate

# You should see (venv) in your terminal prompt

================================================================================
STEP 3: UPGRADE PIP (RECOMMENDED)
================================================================================

python -m pip install --upgrade pip

================================================================================
STEP 4: INSTALL DEPENDENCIES
================================================================================

# Install all dependencies from requirements.txt
pip install -r requirements.txt

# If you encounter errors with pybluez, you can install dependencies one by one:
pip install bluepy>=1.3.0
pip install beautifulsoup4>=4.9.0
pip install requests>=2.25.0

# pybluez may fail on newer Python versions - it's optional for most features
pip install pybluez>=0.23  # Skip if this fails

================================================================================
STEP 5: SET BLUETOOTH PERMISSIONS (LINUX ONLY)
================================================================================

# Grant BLE capabilities to Python (required for scanning without root)
sudo setcap 'cap_net_raw,cap_net_admin+eip' $(readlink -f $(which python3))

# OR run Python scripts with sudo (not recommended for development)
sudo python script.py

================================================================================
VERIFICATION
================================================================================

# Verify bluepy is installed correctly
python -c "import bluepy.btle; print('bluepy installed successfully')"

# Check all imports
python -c "import requests, bs4; print('All core dependencies installed')"

# Test BLE scanning (requires Bluetooth hardware)
python scan.py

================================================================================
TROUBLESHOOTING
================================================================================

Issue: "use_2to3 is invalid" error with pybluez
Solution: This is a known issue with pybluez on Python 3.10+
          The library is optional - skip it if installation fails

Issue: Permission denied when scanning
Solution: Run with sudo OR set capabilities (see Step 5)

Issue: "bluepy-helper not found"
Solution: Ensure bluepy compiled correctly. Try reinstalling:
          pip uninstall bluepy
          pip install bluepy --no-cache-dir

Issue: Cannot find Bluetooth adapter
Solution: - Check Bluetooth is enabled: sudo hciconfig
          - Check adapter status: sudo hciconfig hci0 up
          - Verify with: bluetoothctl

Issue: Import errors after installation
Solution: Make sure virtual environment is activated
          Check with: which python (should show venv path)

================================================================================
DEACTIVATING VIRTUAL ENVIRONMENT
================================================================================

# When done working, deactivate the virtual environment
deactivate

================================================================================
RUNNING EXAMPLE SCRIPTS
================================================================================

# Make sure virtual environment is activated first
source venv/bin/activate

# Scan for BLE devices
python scan.py

# Connect to WitMotion sensor by name
python wit_ble.py -n WT901BLE67

# Connect to specific MAC address
python wit_ble.py -m AA:BB:CC:DD:EE:FF

# Run demo script
python demo.py

================================================================================
ADDITIONAL RESOURCES
================================================================================

- See CLAUDE.md for detailed architecture and development guidance
- bluepy documentation: https://github.com/IanHarvey/bluepy
- BlueZ documentation: http://www.bluez.org/

================================================================================
