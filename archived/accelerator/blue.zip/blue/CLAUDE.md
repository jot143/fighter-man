# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a Bluetooth Low Energy (BLE) sensor interface library for Python. It provides modules to scan, connect, and interact with various BLE devices including:
- Texas Instruments SensorTag (CC2650)
- Nordic Thingy:52
- WitMotion WT901BLE/WT902BLE IMU sensors
- Generic BLE devices

## Architecture

### Core Module Structure

**btle.py** (lines 1-900+)
- Core BLE implementation wrapping bluepy functionality
- Key classes:
  - `Peripheral`: Main class for BLE device connections (line 402+)
  - `Scanner`: Device discovery and scanning
  - `UUID`: UUID handling for BLE services/characteristics
  - `BTLEException`: Exception hierarchy for error handling
- Uses subprocess communication with `bluepy-helper` binary
- Provides low-level GATT operations (read/write/notify)

**sensortag.py**
- Texas Instruments SensorTag device support
- Sensor-specific classes inheriting from `SensorBase` (line 13):
  - `IRTemperatureSensor`: Infrared temperature sensor
  - `AccelerometerSensor`: Motion/acceleration data
  - Other environmental sensors
- Uses TI-specific UUID generation via `_TI_UUID()` (line 5)

**thingy52.py**
- Nordic Thingy:52 multi-sensor platform support
- Service modules:
  - `BatterySensor`: Battery level monitoring (line 85+)
  - Environment sensors (temperature, pressure, humidity, gas, color)
  - Motion sensors (tap, orientation, quaternion, step counter)
  - User interface (LED, button)
  - Sound (speaker, microphone)
- Uses Nordic UUID scheme via `Nordic_UUID()` (line 24)

**wit_ble.py**
- WitMotion IMU sensor interface with command-line scanning
- Handles accelerometer, gyroscope, angle, and magnetometer data
- Data parsing in `CopeData()` function (line 31)
- Uses notification delegates for real-time data streaming

### Common Patterns

**Device Connection Flow:**
1. Scan for devices using `Scanner` with custom `DefaultDelegate`
2. Connect via `Peripheral(device_addr, addr_type)`
3. Set notification delegate with `setDelegate()`
4. Get service/characteristic handles
5. Enable notifications by writing to CCCD (UUID 0x2902)
6. Use `waitForNotifications()` in loop to receive data

**Service Discovery:**
```python
services = peripheral.getServices()
characteristics = peripheral.getCharacteristics()
# Or specific: service.getCharacteristics(uuid)
```

## Environment Setup

### System Requirements

**Linux:**
```bash
# Install BlueZ (Bluetooth stack)
sudo apt-get install libbluetooth-dev bluez

# Grant BLE capabilities to Python (required for scanning)
sudo setcap 'cap_net_raw,cap_net_admin+eip' $(readlink -f $(which python3))
```

**macOS:**
- Built-in Bluetooth support
- May need to run Python scripts with elevated privileges for some operations

### Python Environment

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### Permissions

BLE operations typically require:
- Root/sudo access OR
- Appropriate capabilities set on Python interpreter (Linux)
- Bluetooth hardware must be enabled

## Development Commands

### Testing Device Connectivity

**Scan for BLE devices:**
```bash
python scan.py
```

**Connect to specific device:**
```bash
python connect.py  # Edit hardcoded MAC address first
```

**Test WitMotion sensors:**
```bash
python wit_ble.py -n WT901BLE67  # By device name
python wit_ble.py -m AA:BB:CC:DD:EE:FF  # By MAC address
python wit_ble.py -t 5 -s -60  # 5s scan, filter by RSSI >= -60dBm
```

### Running Example Scripts

**SensorTag demo:**
```bash
python demo.py  # Basic notification handling example
```

**Service discovery:**
```bash
python get_services.py  # Fetch BLE service definitions from web
```

### Common Issues

**Permission Denied:**
- Run with sudo or set capabilities on Python binary
- Check that Bluetooth adapter is powered on

**Connection Timeouts:**
- Ensure device is in pairing/advertising mode
- Check device is within range
- Verify MAC address format is correct (AA:BB:CC:DD:EE:FF)

**Import Errors:**
- Activate virtual environment
- Reinstall requirements: `pip install -r requirements.txt`

## Key Files

- `btle.py`: Core BLE implementation and GATT operations
- `sensortag.py`: TI SensorTag device support with sensor classes
- `thingy52.py`: Nordic Thingy:52 comprehensive sensor suite
- `wit_ble.py`: WitMotion IMU sensors with CLI
- `scan.py`, `connect.py`, `demo.py`: Example/test scripts
- `get_services.py`: Utility to fetch standard BLE service definitions
